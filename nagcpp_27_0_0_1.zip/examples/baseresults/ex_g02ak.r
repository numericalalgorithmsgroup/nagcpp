nagcpp::correg::corrmat_​nearest_rank Example

NCM with rank constraint
         1        2        3        4
1   1.0000  -0.9021   0.2448   0.1975
2  -0.9021   1.0000  -0.6392   0.2448
3   0.2448  -0.6392   1.0000  -0.9021
4   0.1975   0.2448  -0.9021   1.0000

Number of subproblems solved:           4
Squared Frobenius norm of difference:   0.3082
Rank error:                             0.0000
