nagcpp::quad::md_gauss Example
Answer = 0.25065
