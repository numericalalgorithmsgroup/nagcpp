nagcpp::roots::contfn_brent Example
x = 0.56714
