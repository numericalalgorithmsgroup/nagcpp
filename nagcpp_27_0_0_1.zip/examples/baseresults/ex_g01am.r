nagcpp::stat::quantiles Example
  Quantile   Result
 -------------------
    0.00      0.30
    0.25      2.20
    0.50      4.90
    1.00      9.70
