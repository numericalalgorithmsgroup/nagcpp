#ifndef NAGCPP_AVAILABLE_DATA_CONTAINERS_HPP
#define NAGCPP_AVAILABLE_DATA_CONTAINERS_HPP

// uncomment if boost vectors are available and will be used
//#define HAVE_BOOST_VECTOR
// uncomment if boost matrices are available and will be used
//#define HAVE_BOOST_MATRIX

#endif
